"""ÆGIR exact panel assembly. Units: mm. Run python enclosure.py [output-directory]."""
import json, math, pathlib, sys
import cadquery as cq
panels = json.loads("[{\"id\":\"front\",\"label\":\"Front baffle\",\"width\":279.4,\"height\":958.85,\"thickness\":12.7,\"position\":[139.7,479.425,6.35],\"rotation\":[0,0,0],\"holes\":[{\"x\":0,\"y\":168.27500000000003,\"radius\":105.0925},{\"x\":-25.39999999999999,\"y\":371.47499999999997,\"radius\":35.56}]},{\"id\":\"back\",\"label\":\"Back panel\",\"width\":279.4,\"height\":958.85,\"thickness\":12.7,\"position\":[139.7,479.425,336.54999999999995],\"rotation\":[0,0,0],\"holes\":[],\"openings\":[{\"x\":0,\"y\":-409.57500000000005,\"width\":203.2,\"height\":63.5}]},{\"id\":\"left\",\"label\":\"left wall\",\"width\":317.5,\"height\":958.85,\"thickness\":12.7,\"position\":[6.35,479.425,171.45],\"rotation\":[0,1.5707963267948966,0],\"holes\":[]},{\"id\":\"right\",\"label\":\"right wall\",\"width\":317.5,\"height\":958.85,\"thickness\":12.7,\"position\":[273.04999999999995,479.425,171.45],\"rotation\":[0,1.5707963267948966,0],\"holes\":[]},{\"id\":\"top\",\"label\":\"top cap\",\"width\":253.99999999999997,\"height\":317.5,\"thickness\":12.7,\"position\":[139.7,952.5,171.45],\"rotation\":[1.5707963267948966,0,0],\"holes\":[]},{\"id\":\"bottom\",\"label\":\"bottom cap\",\"width\":253.99999999999997,\"height\":317.5,\"thickness\":12.7,\"position\":[139.7,6.35,171.45],\"rotation\":[1.5707963267948966,0,0],\"holes\":[]},{\"id\":\"tapered-divider\",\"label\":\"Published single-fold divider · 83.9 degrees\",\"width\":254,\"height\":777.7324627417753,\"thickness\":12.7,\"position\":[139.7,400.05,231.81074633265817],\"rotation\":[-0.10615680151263622,0,0],\"holes\":[]}]")
out = pathlib.Path(sys.argv[1] if len(sys.argv)>1 else "cad-output")
out.mkdir(parents=True, exist_ok=True)
assembly = cq.Assembly(name="Aegir_Enclosure")
for p in panels:
    if p.get("footprint"):
        f=p["footprint"]
        part=cq.Workplane("XY").polyline(f["polygon"]).close().extrude(f["depth"]).translate((0,0,f["z"]))
        local=part.translate(tuple(-v for v in p["position"]))
        for axis,angle in reversed(list(zip([(1,0,0),(0,1,0),(0,0,1)],p["rotation"]))):
            if angle: local=local.rotate((0,0,0),axis,-math.degrees(angle))
    else:
        part=cq.Workplane("XY").box(p["width"],p["height"],p["thickness"])
        for hole in p["holes"]:
            part=part.cut(cq.Workplane("XY").center(hole["x"],hole["y"]).circle(hole["radius"]).extrude(p["thickness"]+2,both=True))
        for opening in p.get("openings",[]):
            part=part.cut(cq.Workplane("XY").center(opening["x"],opening["y"]).rect(opening["width"],opening["height"]).extrude(p["thickness"]+2,both=True))
        local=part
        for axis,angle in zip([(1,0,0),(0,1,0),(0,0,1)],p["rotation"]):
            if angle: part=part.rotate((0,0,0),axis,math.degrees(angle))
        part=part.translate(tuple(p["position"]))
    cq.exporters.export(local,str(out/(p["id"]+".stl")))
    assembly.add(part,name=p["id"],color=cq.Color(0.72,0.53,0.32))
assembly.export(str(out/"enclosure.step"))
print(str(out/"enclosure.step"))
