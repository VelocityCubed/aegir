// ÆONFORGE ÆGIR | millimetres | export each panel separately for fabrication
// Line centreline 1.80975 m; 0 Np/m loss at 100 Hz
$fn=128;
// Front baffle
translate([139.7,479.425,6.35]) rotate([0,0,0]) difference(){
 cube([279.4,958.85,12.7],center=true);
 translate([0,168.275,0]) cylinder(h=14.7,r=105.0925,center=true);
 translate([-25.4,371.475,0]) cylinder(h=14.7,r=35.56,center=true);

}

// Back panel
translate([139.7,479.425,336.55]) rotate([0,0,0]) difference(){
 cube([279.4,958.85,12.7],center=true);

 translate([0,-409.57500000000005,0]) cube([203.2,63.5,14.7],center=true);
}

// left wall
translate([6.35,479.425,171.45]) rotate([0,90,0]) difference(){
 cube([317.5,958.85,12.7],center=true);


}

// right wall
translate([273.05,479.425,171.45]) rotate([0,90,0]) difference(){
 cube([317.5,958.85,12.7],center=true);


}

// top cap
translate([139.7,952.5,171.45]) rotate([90,0,0]) difference(){
 cube([254,317.5,12.7],center=true);


}

// bottom cap
translate([139.7,6.35,171.45]) rotate([90,0,0]) difference(){
 cube([254,317.5,12.7],center=true);


}

// Published single-fold divider · 83.9 degrees
translate([139.7,400.05,231.81075]) rotate([-6.08234,0,0]) difference(){
 cube([254,777.73246,12.7],center=true);


}
